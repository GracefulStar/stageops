"""StageOps rental API."""
